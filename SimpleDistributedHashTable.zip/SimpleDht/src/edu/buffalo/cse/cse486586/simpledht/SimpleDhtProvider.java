package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.TreeMap;

//import edu.buffalo.cse.cse486586.groupmessenger.GroupMessengerActivity.ClientTask;

//import edu.buffalo.cse.cse486586.groupmessenger.GroupMessengerActivity.ServerTask;

//import edu.buffalo.cse.cse486586.groupmessenger.GroupMessengerProvider.DatabaseHelper;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.SlidingDrawer;

public class SimpleDhtProvider extends ContentProvider {
	
	SQLiteDatabase database1;
//	static String dbName = "MyDatabase";
	DatabaseHelper databaseHelper1;
	static String tablename;
	String msgType;
	String prev,next;
	String myPort;
	static final int SERVER_PORT = 10000;
	static int dbVersion;
	String auth ;
	int tempFlag=0;
	Uri contentUri;
	static String dataBaseName;
	Object lock = new Object();
	static String KEY_FIELD;
	static String VALUE_FIELD;
	boolean alreadySentGlobalDumpReq = false;
	MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key","value"});
	MatrixCursor matrixCursor1;
	String globalSelection;
	int tempFlag1=0;
	boolean globalDelete = false;
	boolean alreadyJoined=false;
	boolean deleteflag=false;
	String msgPckt;
	TreeMap<String,Integer > treemap= new TreeMap<String,Integer>();
	protected void onCreate(Bundle savedInstanceState) {
	
	}
	
	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];
			try{
				BufferedReader br;
				while(true){
						br = new BufferedReader(new InputStreamReader(serverSocket.accept().getInputStream()));
						String msgPacket = br.readLine();
						Log.e("in server ", msgPacket);
						String splitMsg[] = msgPacket.split("-");
						String msgType =splitMsg[0];
						String fromPort=splitMsg[1];
						String toPort=splitMsg[2];
						String key=splitMsg[3];
						String value = splitMsg[4];
						String prevOfRequestingPort = splitMsg[5];
						String nextOfRequestingPort = splitMsg[6];
						String nextToSend,prevToSend,msgPcktToSend;
						if(splitMsg[0].equals("JoinReq")){
							if(myPort.equals("11108")){
								
								treemap.put(genHash(Integer.toString((Integer.parseInt(fromPort))/2)), Integer.parseInt(fromPort));
								if(treemap.higherEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2)))!= null){
									Log.e("in server joinreq","next is "+treemap.higherEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2))).getValue());
									nextToSend = Integer.toString(treemap.higherEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2))).getValue());
								}
								else{
									Log.e("in server joinreq","next is "+treemap.firstEntry().getValue());
									nextToSend = Integer.toString(treemap.firstEntry().getValue());
								
								}
								if(treemap.lowerEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2)))!= null){
									Log.e("in server joinreq","prev is " + treemap.lowerEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2))).getValue());
									prevToSend = Integer.toString(treemap.lowerEntry(genHash(Integer.toString((Integer.parseInt(fromPort))/2))).getValue());
								}
								else{
									Log.e("in server joinreq","prev is " + treemap.lastEntry().getValue());
									prevToSend = Integer.toString(treemap.lastEntry().getValue());
								}
								
							//	msgPcktToSend = "update"+"-"+myPort+"-"+nextToSend+"-"+"/"+"-"+"/"+"-"+fromPort+"-"+"/";
							//	new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPcktToSend);
								client c=new client("update",myPort,nextToSend,"/","/",fromPort,"/");
								Thread thread = new Thread(c);
								thread.start();
								
								
								msgPcktToSend = null;
								
								msgPcktToSend = "update"+"-"+myPort+"-"+prevToSend+"-"+"/"+"-"+"/"+"-"+"/"+"-"+fromPort;
							//	new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPcktToSend);
								client c1=new client("update",myPort,prevToSend,"/","/","/",fromPort);
								Thread thread1 = new Thread(c1);
								thread1.start();
								msgPcktToSend = null;
																
								msgPcktToSend = "update"+"-"+myPort+"-"+fromPort+"-"+"/"+"-"+"/"+"-"+prevToSend+"-"+nextToSend;
							//	new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPcktToSend);
								client c2=new client("update",myPort,fromPort,"/","/",prevToSend,nextToSend);
								Thread thread2 = new Thread(c2);
								thread2.start();
								
								msgPcktToSend = null;
							}
							
							
						}
						if(msgType.equals("update")){
							if(!prevOfRequestingPort.equals("/"))
								prev = prevOfRequestingPort;
							if(!nextOfRequestingPort.equals("/"))
								next = nextOfRequestingPort;
							Log.e("next is ",next);
							Log.e("prev is ",prev);
						}
						if(splitMsg[0].equals("insert find destination")){
							String portToSend;
							String msgPcktToSend1;
							if(treemap.higherEntry(genHash(key))!=null)
								portToSend = Integer.toString(treemap.higherEntry(genHash(key)).getValue());
							else
								portToSend = Integer.toString(treemap.firstEntry().getValue());
							msgPcktToSend1 = "insert into table"+"-"+"11108"+"-"+portToSend+"-"+key+"-"+value+"-"+"/"+"-"+"/";
							//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPcktToSend1);
							client c=new client("insert into table","11108",portToSend,key,value,"/","/");
							Thread thread = new Thread(c);
							thread.start();
						}
						if(splitMsg[0].equals("insert into table")){
							 	Log.e("inserting into "+toPort,key+" "+value);
								ContentValues c=new ContentValues();
								c.put("key", key);
								c.put("value", value);
								database1.insertWithOnConflict(tablename, null, c, SQLiteDatabase.CONFLICT_REPLACE);
						}
						if(splitMsg[0].equals("global dump req")){
							if(!myPort.equals(fromPort)){
								
								Cursor c= query(contentUri, null, "@", null, null);
								String keysForGlobalDump = null,valuesForGlobalDump = null;
								Log.e("count",Integer.toString(c.getCount()));
								if(c.getCount()>=1){
									while(c.moveToNext()){
										int key1 =c.getColumnIndex("key");
										int value1 = c.getColumnIndex("value");
										String returnKey = c.getString(key1);
										String returnValue = c.getString(value1);
										if(key.equals("/")){
											if(keysForGlobalDump ==null)
												keysForGlobalDump = returnKey;
											else
												keysForGlobalDump = keysForGlobalDump+","+returnKey;

											if(valuesForGlobalDump ==null)
												valuesForGlobalDump = returnValue;
											else
												valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
										}
										else{
											if(keysForGlobalDump ==null)
												keysForGlobalDump = key+","+returnKey;
											else
												keysForGlobalDump = keysForGlobalDump+","+returnKey;

											if(valuesForGlobalDump ==null)
												valuesForGlobalDump = value+","+returnValue;
											else
												valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
										}

									}
								}
								else{
									if(key.equals("/")){
										if(keysForGlobalDump ==null)
											keysForGlobalDump = "/";
										if(valuesForGlobalDump ==null)
											valuesForGlobalDump = "/";
										
									}
									else{
										
											keysForGlobalDump = key;
											valuesForGlobalDump = value;
										
									}
								}
								
								
								msgPckt = "global dump req"+"-"+fromPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
							//	new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
								client c3=new client("global dump req",fromPort,next,keysForGlobalDump,valuesForGlobalDump,"/","/");
								Thread thread3 = new Thread(c3);
								thread3.start();
								
							}
							else{
								//lock.notify();
								matrixCursor1 = new MatrixCursor(new String[]{"key","value"});
								String[] splitKeysOfGlobalDump = key.split(",");
								String[] splitValuesOfGlobalDump = value.split(",");
							
								int size = splitKeysOfGlobalDump.length;
						
								for(int i=0;i<size;i++){
									matrixCursor.addRow(new Object[]{splitKeysOfGlobalDump[i],splitValuesOfGlobalDump[i]});
								}
								
								while(matrixCursor.moveToNext()){
									if(matrixCursor.getString(0).equals(globalSelection)){
										matrixCursor1.addRow(new Object[]{matrixCursor.getString(0),matrixCursor.getString(1)});
										break;
									}
								}
								
								tempFlag=1;
								tempFlag1=1;
								
								Log.e("hh","hh");
							}
						}
						if(splitMsg[0].equals("delete")){
							Log.e("global del",myPort);
							int rowCount = database1.delete(tablename, "1", null);
							if(myPort.equals(fromPort)){
								globalDelete = true;
								Log.e("Global delete","successful");
							}
							else{
								client c=new client("delete",fromPort,next,"/","/","/","/");
								Thread thread = new Thread(c);
								thread.start();
							}
						}

					}
				}catch(Exception e){
					Log.e("exception","exception");
				}

			return null;
		}
	}
	
	private int findSucc(String string) {
		int id = getId(string);
		return id;
	}
	
	private class ClientTask extends AsyncTask<String, Void, Void> {
		
		@Override
		protected Void doInBackground(String... msg) {
			String wholeMsg = msg[0];
			String splitMsg[]=wholeMsg.split("-");
			String msgType =splitMsg[0];
			String fromPort=splitMsg[1];
			String toPort=splitMsg[2];
			String key=splitMsg[3];
			try{
				Socket socket=new Socket("10.0.2.2",Integer.parseInt(toPort));
				PrintWriter toServer = null;
				toServer = new PrintWriter(socket.getOutputStream(), true);
				msgPckt = wholeMsg;
				toServer.println(msgPckt);
				socket.close();
			}catch(Exception e){
		
			}
			
			return null;
		}

	}
	
	private int getId(String myPort) {
		if(myPort.equals("11108"))
			return 0;
		if(myPort.equals("11112"))
			return 1;
		if(myPort.equals("11116"))
			return 2;
		if(myPort.equals("11120"))
			return 3;
		if(myPort.equals("11124"))
			return 4;
		return -1;
	}
	private static class DatabaseHelper extends SQLiteOpenHelper {
    	DatabaseHelper(Context context) {
    		super(context, dataBaseName, null, dbVersion);
    	}

    	@Override
    	public void onCreate(SQLiteDatabase db) {
    		db.execSQL("CREATE TABLE " + tablename + "(" + KEY_FIELD + " text primary key, " + VALUE_FIELD + " text not null );");
    	//	db.execSQL("CREATE TABLE  DHTTable ( key text primary key, value text not null );");
    	}

    	@Override
    	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    	//	Log.w(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
    		db.execSQL("DROP TABLE IF EXISTS " + tablename);
    		onCreate(db);
    	}
    }
	
	
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
    	
    	
//    	if(selection.equals("@")){
//    		int rowCount = database1.delete(tablename, "1", null); 
//			return rowCount;

    //	}
    //	else if(selection.equals("*")){
    		if(prev.equals(next) && prev.equals(myPort)){
    			int rowCount = database1.delete(tablename, "1", null); 
    			deleteflag=true;
    			return rowCount;
    		}
    		else{
    			Log.e("global del","global delete");
    			deleteflag=true;
    			int rowCount = database1.delete(tablename, "1", null);
    			client c=new client("delete",myPort,next,"/","/","/","/");
        		Thread thread = new Thread(c);
        		thread.start();
    		}
//        	/*	while(true){
//    				if(globalDelete)
//    					break; 
//    			}
//        		Log.e("after busy waiting","global delete");
//    			if(globalDelete == true){
//    				globalDelete = false; 
    		//	}*/
    	//	}
   // 	}
     //   return 0;
    	
    	
        		
    	return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
    	if(prev.equals(next) && prev.equals(myPort)){
    		long rowId = database1.insertWithOnConflict(tablename, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    	}
    	else{
    		Log.e("in CP",(String) values.get(KEY_FIELD));
    		msgPckt = "insert find destination"+"-"+myPort+"-"+"11108"+"-"+(String) values.get(KEY_FIELD)+"-"+(String) values.get(VALUE_FIELD)+"-"+"/"+"-"+"/";
    		//	new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
    		client c=new client("insert find destination",myPort,"11108",(String) values.get(KEY_FIELD),(String) values.get(VALUE_FIELD),"/","/");
    		Thread thread = new Thread(c);
    		thread.start();
    		return uri;
    	}
    	return null;
	}

    @Override
    public boolean onCreate() {
    	
    	//Context context = null;
    	tablename = "DHTTable";
    	dbVersion = 2;
    	auth ="edu.buffalo.cse.cse486586.simpledht.provider";
    	contentUri = Uri.parse("content://" + auth);
    	dataBaseName = "MyDHTDatabase";
    	KEY_FIELD ="key";
    	VALUE_FIELD = "value";
    	TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		//if(myPort.equals("11108")){
			prev=myPort;
			next = myPort;
		//}
		
		databaseHelper1 = new DatabaseHelper(getContext());
		 database1 = databaseHelper1.getWritableDatabase();
		 try {
				ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
				new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
			} catch (IOException e) {

				Log.e("hh", "Can't create a ServerSocket");
			//	return;
			}
			msgPckt="JoinReq"+"-"+myPort+"-"+"11108"+"-"+"/"+"-"+"/"+"-"+"/"+"-"+"/";
			Log.e("in server", "executing client task");
			if(myPort.equals("11108")){
				try {
					treemap.put(genHash("5554"), 11108);
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(!myPort.equals("11108"))
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
		 
		 
		 
		 if (database1 == null) {
			return false;
		 } else { 
			return true;
		 }
	}

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
				
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		qb.setTables(tablename);
	
		
		if(deleteflag==true)
			return null;
		else if(selection.equals("@")){
			Cursor cursor1 = null;
			cursor1 = qb.query(
					database1, 
					projection, 
					null, 
					selectionArgs, 
					null, 
					null, 
					sortOrder);
			return cursor1;
		}
		else if(selection.equals("*")){
			tempFlag=0;
			Cursor cursor2 = null;
			cursor2 = qb.query(
					database1, 
					projection, 
					null, 
					selectionArgs, 
					null, 
					null, 
					sortOrder);
			String keysForGlobalDump = null;
			String valuesForGlobalDump =null  ;
			if(cursor2.getCount()>=1){
				while(cursor2.moveToNext()){
					int key =cursor2.getColumnIndex("key");
					int value = cursor2.getColumnIndex("value");
					String returnKey = cursor2.getString(key);
					String returnValue = cursor2.getString(value);
					if(keysForGlobalDump==null)
						keysForGlobalDump =returnKey;
					else
						keysForGlobalDump = keysForGlobalDump+","+returnKey;

					if(valuesForGlobalDump==null)
						valuesForGlobalDump = returnValue;
					else
						valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
				}
			}
			if(keysForGlobalDump!=null){
				msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
				//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
				client c=new client("global dump req",myPort,next,keysForGlobalDump,valuesForGlobalDump,"/","/");
				Thread thread = new Thread(c);
				thread.start();
			}
			else{
				msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
				//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
				client c=new client("global dump req",myPort,next,"/","/","/","/");
				Thread thread = new Thread(c);
				thread.start();
			}
			
			while(tempFlag==0){
				;
			}
			return matrixCursor;
		
			
		}
		else{
			if(prev.equals(next) && prev.equals(myPort))
	    	{
				qb.appendWhere("key" + " = '" + selection + "'");
				Cursor c = null;
				c = qb.query(database1,projection,null,selectionArgs,null,null,sortOrder);
				return c;
	    	}
			
			else{
			globalSelection = new String();
			globalSelection = selection;
			tempFlag1=0;
			Cursor cursor3 = null;
			cursor3 = qb.query(
					database1, 
					projection, 
					null, 
					selectionArgs, 
					null, 
					null, 
					sortOrder);
			String keysForGlobalDump = null;
			String valuesForGlobalDump =null  ;
			if(cursor3.getCount()>=1){
				while(cursor3.moveToNext()){
					int key =cursor3.getColumnIndex("key");
					int value = cursor3.getColumnIndex("value");
					String returnKey = cursor3.getString(key);
					String returnValue = cursor3.getString(value);
					if(keysForGlobalDump==null)
						keysForGlobalDump =returnKey;
					else
						keysForGlobalDump = keysForGlobalDump+","+returnKey;

					if(valuesForGlobalDump==null)
						valuesForGlobalDump = returnValue;
					else
						valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
				}
			}
			if(keysForGlobalDump!=null){
				msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
				//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
				client c=new client("global dump req",myPort,next,keysForGlobalDump,valuesForGlobalDump,"/","/");
				Thread thread = new Thread(c);
				thread.start();
			}
			else{
				msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
				//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgPckt);
				client c=new client("global dump req",myPort,next,"/","/","/","/");
				Thread thread = new Thread(c);
				thread.start();
			}
			while(tempFlag1==0){
				;
			}
			return matrixCursor1;
		}
			
		}
		
	//	return null;
	}

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
    
    
    
    class client implements Runnable{
    	String type,fromPort,toPort,key,value,prev, next =null;
    	
    	public client(String type,String fromPort,String toPort,String key,String value,String prev, String next) {
    		
    		this.type=type;
    		this.fromPort = fromPort;
    		this.toPort=toPort;
    		this.key=key;
    		this.value=value;
    		this.prev = prev;
    		this.next = next;
    	}
    	
    	
    	public void run() {
    		
    		String msgPacket = type+"-"+fromPort+"-"+toPort+"-"+key+"-"+value+"-"+prev+"-"+next;
    		String wholeMsg = msgPacket;
			String splitMsg[]=wholeMsg.split("-");
			String msgType =splitMsg[0];
			String fromPort=splitMsg[1];
			String toPort=splitMsg[2];
			String key=splitMsg[3];
		
				Socket socket = null;
				try {
					socket = new Socket("10.0.2.2",Integer.parseInt(toPort));
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				PrintWriter toServer = null;
				try {
					toServer = new PrintWriter(socket.getOutputStream(), true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				msgPckt = wholeMsg;
				toServer.println(msgPckt);
				try {
					socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			
    } 
    
    }
    
}
