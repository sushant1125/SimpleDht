package edu.buffalo.cse.cse486586.simpledht;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteQueryBuilder;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SimpleDhtActivity extends Activity {


	Uri providerUri = Uri.parse("content://edu.buffalo.cse.cse486586.simpledht.provider");
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_simple_dht_main);

		TextView tv = (TextView) findViewById(R.id.textView1);
		tv.setMovementMethod(new ScrollingMovementMethod());
		findViewById(R.id.button3).setOnClickListener(
				new OnTestClickListener(tv, getContentResolver()));

		final Button ldump = (Button) findViewById(R.id.button1);
		ldump.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {

				TextView tv1 = (TextView) findViewById(R.id.textView1);
				Cursor resultCursor = getContentResolver().query(providerUri, null,"@", null, null);
				while(resultCursor.moveToNext())

				{				
					tv1.append("**********************");
					int key = resultCursor.getColumnIndex("key");
					int value = resultCursor.getColumnIndex("value");

					String returnKey = resultCursor.getString(key);
					String returnValue = resultCursor.getString(value);

					tv1.append("\t" + returnKey+"----"+returnValue + "\n");

				}

			}
		});		
		
		final Button gdump = (Button) findViewById(R.id.button2);
		gdump.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {

				TextView tv2 = (TextView) findViewById(R.id.textView1);
				Cursor resultCursor = getContentResolver().query(providerUri, null,"*", null, null);
				
				while(resultCursor.moveToNext())
				{				
					tv2.append("^^^^^^^^^^^^");
					int key = resultCursor.getColumnIndex("key");
					int value = resultCursor.getColumnIndex("value");

					String returnKey = resultCursor.getString(key);
					String returnValue = resultCursor.getString(value);

					tv2.append("\t" + returnKey+"----"+returnValue + "\n");				
				}
			}
		});

		

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_simple_dht_main, menu);
		return true;
	}

}
